import React, { useState } from "react";
import styles from "./style.module.css";
import WishlistIcon from "../../icons/wishlist";
import CartIcon from "../../icons/cart";
import Button from "../button";
import CartItem from "./cartItem";

const SiteBar = () => {
  const [open, setOpen] = useState(false);
  const handleOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };
  return (
    <>
      <div className={styles.sitebar}>
        <button onClick={handleOpen}>
          <CartIcon />
        </button>
        <span>2</span>
      </div>
      {open && (
        <div className={styles.site_bar_add}>
          <div className={styles.sba_wrapper}>
            <div className={styles.sbaw_title}>
              <h2>Shopping</h2>
              <div className={styles.sbawt_count}>(2)</div>
              <Button
                title={"close"}
                btnStyle={"outline"}
                type={"submit"}
                onClick={handleClose}
              />
            </div>
            <div className={styles.sba_content}>
              <CartItem />
              <CartItem />
              <CartItem />
              <CartItem />
              <CartItem />
            </div>
            <div className={styles.sba_footer}>
              <button className={styles.sbaaf_btn1}>Checkout</button>
              <button className={styles.sbaaf_btn1}>View Cart</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
export default SiteBar;
